create database my_board;
use my_board;
drop table board;
create table board(
b_no int primary key auto_increment,
b_title char(20),b_id char(20),b_datetime char(20),b_text char(50),b_hit int,b_pass char(20),log_no int,hit int,worst int,report int);
 select * from board;

drop table member;
create table member(
m_no int primary key auto_increment,
u_id char(20),u_pw char(20),admin_no int,name char(20),sex char(20),Y int,M int,D int,tel int,tel2 int,tel3 int);
select * from member;


drop table reply;
create table reply(
re_no int primary key auto_increment,
b_reply_ori int,b_reply_text char(50),b_reply_id char(20),b_reply_pass char(20),re_datetime char(20),b_reply_log_no char(20));
select * from reply;
select * from reply where b_reply_ori=1;

drop table re_reply;
create table re_reply(
r_r_no int primary key auto_increment,
r_no int,r_reply_ori int,r_reply_text char(50),r_reply_id char(20),r_reply_pass char(20),r_re_datetime char(20),r_reply_log_no char(20));
select * from re_reply;